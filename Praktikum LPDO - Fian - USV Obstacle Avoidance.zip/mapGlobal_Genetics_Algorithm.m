function [GlobalOut] =GA(u)
enGA=u(11);

% WAYPOINT tanpa GA
GlobalOut=zeros(7,2); %WAYPOINT 7x2

if enGA==1
wp=2;
% globalvariables
tic;
pop=20; %population size
vp=[1 2 3 4 5]; %number of via points / gene length
rad_REAL=u(12); %RADIUS OF REAL OBSTACLE #################################
%Karena USV memiliki panjang kapal 6 m, lebar 1,5 m maka path kapal harus
%memiliki jarak minimum ke obstacle sekitar +-1 m
rad=rad_REAL+2;
start=[round(u(7)) round(u(8))];
final=[round(u(9)) round(u(10))];
% wp1=[start]; %starting point => WAYPOINT 1 [x;y]
% wp2=[final]; %nd point => WAYPOINT 3      [x;y]
map_size=final(1); 
WPGA=[start;final]; %WAYPOINT

%% posible locations
pos_map=[];
for k=1:map_size+1
for l=1:map_size+1
pos_map_t=[l-1;k-1];
pos_map=[pos_map pos_map_t];
end
end

%% Collision Position
% obs_total=[u(1) u(2);u(3) u(4);u(5) u(6)];
obs_total=[u(1) u(2);u(3) u(4)];
obs_map=obs_total';

%% possible location & Waypoint & obstacle position
pos=pos_map;
sp=[WPGA(1,1);WPGA(1,2)];
ep=[WPGA(2,1);WPGA(2,2)];
obs=obs_map;

%% pastikan via points tidak pada sp/ep/obs
no_via_ind1 =find((pos(1,:)==sp(1)&pos(2,:)==sp(2))|(pos(1,:)==ep(1)&pos(2,:)==ep(2)));
no_via_ind2=[];
for i=1:size(obs,2)
no_via_ind2=[no_via_ind2 find((pos(1,:)-obs(1,i)).^2+(pos(2,:)-obs(2,i)).^2<=rad^2)];
%titik yg di dlm obs
end
no_via = union(no_via_ind1,no_via_ind2);

sop=pos;
sopp=sop;
sop(:,no_via_ind1)=[];

pos(:,no_via)=[];

% figure(21)
% plot(Waypoint(:,1),Waypoint(:,2),'g*');
% hold on
% line(Waypoint(:,1),Waypoint(:,2))
% hold on
% plot(obs_map(1,:),obs_map(2,:),'ro','markersize',rad_REAL*28)
% xlim([sp(1) ep(1)])
% ylim([sp(2) ep(2)])
% title('Path Sebelum Algoritma Menghindari Halangan diterapkan');
% 
% figure(22)
% plot(pos(1,:), pos(2,:), 'ro' );
% xlim([sp(1) ep(1)])
% ylim([sp(2) ep(2)])
% title('Possible Via Points' );
% figure(23)
% plot(sop(1,:), sop(2,:), 'bo');
% xlim([sp(1) ep(1)])
% ylim([sp(2) ep(2)])
% title('Titik yang Mungkin Dilewati');

poos=[pos;zeros(2,length(pos))];

for u=1:length(pos)
   if abs(poos(1,u)-poos(2,u))>=0
      poos(3,u)=5;
   else
      poos(3,u)=2;
   end
end

u1=sum(poos(3,:)==5);
u2=sum(poos(3,:)==2);
for j=1:length(pos)
if poos(3,j)==5
poos(4,j)=0.95/u1;
else
poos(4,j)=0.05/u2;
end
end
%0.55 0.45
% figure(24)
% for ii=1:length(poos)
% if poos(3,ii)==5
% plot(poos(1,ii), poos(2,ii), 'ro');
% hold on
% else
% plot(poos(1,ii), poos(2,ii), 'bo');
% hold on
% end
% end
% xlim([sp(1) ep(1)])
% ylim([sp(2) ep(2)])
% title('Titik yang Menjadi Path kapal')

[xch,ych]=generate_chr(pop,vp(wp),pos,sp,obs,ep,rad,poos); %generate chromosome yang mungkin
ch_dist=[];
for i=2:vp(wp)+2
ch_dist(:,i-1)= sqrt((xch(:,i-1)- xch(:,i)).^2+(ych(:,i-1)-ych(:,i)).^2);
end
ch_fitness = sum(ch_dist')';
best_ch_ind= find(ch_fitness == min(ch_fitness));
ch_order = [[1:length(ch_fitness)']' ch_fitness];
ch_order = sortrows(ch_order,2); %re-oder chromosomes menurut fitness
konv_fitness=[];
%% iteration
ite=0;
NN=30;
for generation = 1:NN

Pc=0.9;
Pm=0.35;
elite= ch_order(1,:);
xe=xch(elite(:,1),:);
ye=ych(elite(:,1),:);
order=ch_order(2:end,:);
bit=round(rand*(vp(wp)-1));

[xchild1,ychild1] = cross(order,xch,ych,Pc,bit,vp(wp));
chn_size=0;
chn_size= pop-size(xchild1,1);

[xchld2,ychld2]=generate_chr(chn_size,vp(wp),pos,sp,obs,ep,rad,poos);
%buat jumlah current population = starting population
xchild1=[xchild1;xchld2];
ychild1=[ychild1;ychld2];
[xchild2,ychild2]=mutate(xchild1,ychild1,pos,Pm,obs,rad,poos);
%%%update chromosome
xchn= xchild2;
ychn= ychild2;
%jika chromosome kurang, buat baru
chn_size=0;
chn_size= pop-size(xchn,1);
[xchn2,ychn2]=generate_chr(chn_size,vp(wp),pos,sp,obs,ep,rad,poos);
xch_t= [xchn ; xchn2];
xch(2:end,:)= xch_t(1:pop-1,:);
xch(1,:)=xe;
ych_t= [ychn ; ychn2];
ych(2:end,:)= ych_t(1:pop-1,:);
ych(1,:)=ye;
%OUTPUT xch ych ###########++++++++++++#############+++++++++++++##########

%%%chromosome re-evaluation
ch_dist=[];
for i=2:vp(wp)+2
ch_dist(:,i-1)=sqrt((xch(:,i-1)-xch(:,i)).^2+(ych(:,i-1)-ych(:,i)).^2);
end
ch_fitness = sum(ch_dist')';
best_ch_ind=find(ch_fitness==min(ch_fitness));

ch_order = [[1:length(ch_fitness)']' ch_fitness] ;
ch_order = sortrows(ch_order,2);  %reoder the chromosomes menurut fitness

lols=min(ch_fitness);
konv_fitness=[konv_fitness lols];


ch_pick=1;
%% hasil pada generasi ke x
%FIX
if generation==NN
order=ch_order;
best=ch_order(ch_pick,1);
Lpath=order(ch_pick,2);
xch=[xch(best(1),:)];
ych=[ych(best(1),:)];
end
% figure(35)
% plot(xch,ych,'g*')
% hold on
% line(xch,ych)
% plot(obs_map(1,:),obs_map(2,:),'ro','markersize',rad_REAL*28)
% title('the best chromosome at the 50th generation')
% text(12,30,['path length =',num2str(Lpath)])
% hold off
% print('-dtiff',['ob3_10_',num2str(wp)])
% end

ite=ite+1;
end

toc;
Length_Path=[konv_fitness];
% figure(37)
% plot(1:ite,Length_Path)
% title('min. distance found')
% xlabel('generation')
% ylabel('distance')

%Save xch ych generation-i to FIX xch ych
xch_best=xch;
ych_best=ych;

% CEK if WP ke-2 berdekatan dengan titik awal USV GA WP ke-1 ############
% if sqrt((xch_best(2)-xch_best(1))^2+(ych_best(2)-ych_best(1))^2)<=5
% xch_best(2)=xch_best(2)+3;
% ych_best(2)=ych_best(2)+3;
% end

% %Hitung Jarak Path BARU jika ada perubahan xch ych
% ch_dist=[];
% for i=2:length(xch_best)
% ch_dist(:,i-1)=sqrt((xch_best(:,i-1)-xch_best(:,i)).^2+(ych_best(:,i-1)-ych_best(:,i)).^2);
% end
% ch_fitness = sum(ch_dist')';
% best_ch_ind=find(ch_fitness==min(ch_fitness));
% ch_order = [[1:length(ch_fitness)']' ch_fitness] ;
% ch_order = sortrows(ch_order,2);  %reoder the chromosomes menurut fitness
% Jarak_Path=min(ch_fitness);

%OUTPUT MAIN FUCNTION GA >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Xx=[xch_best(1:end) Length_Path(end) toc 1]; %1 untuk GA aktif
Yy=[ych_best(1:end) Length_Path(end) toc 1];
GlobalOut=[Xx' Yy']; %7x2
end

%END MAIN FUNCTION ######################################################
end


%########################################################################
%%FUNCTIONxx
function [Xch,Ych] = generate_chr(n,vp,pos,sp,obs,ep,rad,poos)
i=1;
Xch=zeros(n,vp+2);
Ych=zeros(n,vp+2);
%a=true;
while i < n+1
    %chs_ind=datasample(1:409,2,'Replace',a,'Weights',poos(4,:));
chs_ind=randsample(1:length(pos),vp,true,poos(4,:)); %pop size dari possible comb.
                   %rentang nilai,jumlah sample,true,weighted sampling    

ch_t=[sp pos(:,chs_ind) ep];

[test_result]=test_chr(ch_t(1,:),ch_t(2,:),obs,rad);
if test_result == 1
Xch(i,:)= ch_t(1,:);
Ych(i,:)= ch_t(2,:);
i=i+1;
%a=false;
end
end
end


function [test_result]=test_chr(xc,yc,obs,rad)
clear test_result;
rad=rad+0.25;
v_fit=zeros(size(xc,2),length(obs),size(xc,1));
for p=1: size(xc,1)
for q=2: size(xc,2)
for r=1: length(obs)
x2= xc(p,q);
y2=yc(p,q);
x1=xc(p,q-1);
y1=yc(p,q-1);
x0=obs(1,r);
y0=obs(2,r);
if x1==x2 %%cari xsol ysol dulu
pol1=1;
pol2= -2*y0;
pol3= y0^2+x1^2-2*x0*x1+x0^2-rad^2;
ysol= roots([pol1 pol2 pol3]);
xsol= [x1;x2];
%%%% else represent in polynoimal,descending order of X
else
m=(y2-y1)/(x2-x1);
c=y1-m*x1;
pol1= m^2+1;
pol2= (2*m*c-2*y0*m-2*x0);
pol3= c^2-2*y0*c+y0^2+x0^2-rad^2;
xsol= roots([pol1 pol2 pol3]);
ysol= m*xsol + c;
end
sol= [xsol,ysol];
sol_d = dist([x1,y1],[xsol';ysol']);
obs_d = dist([x1,y1],[x0;y0]);
if isreal(sol) && (obs_d > min(sol_d) && obs_d < max(sol_d))
v_fit(q,r,p ) = 1;
end
end
if sum(sum(v_fit(:,:,p))) <1
test_result(p)=1;
else
test_result(p)=0;
end
end
end
end

%% 1 point crossover pada posisi bit ke-1
function [xchild,ychild] = cross(order,xch,ych,Pc,bit,vp)
if bit < 0 || bit > 5
error('choose diff bit number')
return
end
ch_fitness_t = order(:,2);
ch_fitness= 1./ch_fitness_t;
p= ch_fitness/(sum(ch_fitness)); 
xp= xch(order(:,1),:);
yp= ych(order(:,1),:);
for i=1:length(p)
q(i)=sum(p(1:i));
end
%%chromosome clone
roulette=rand(1,length(p));
for i=1:length(p)
qk_t=find(q>roulette(i));
qk(i)=qk_t(1);
end
xp=xp(qk,:);
yp=yp(qk,:);
%%chromosome crossover
roulette=rand(1,length(p));
vc=find(roulette<Pc);
xparent = xp;
xhead= xparent(vc,1:vp-bit);
xtail=xparent(vc,vp-bit+1:end);
yparent = yp ;
yhead= yparent(vc, 1:vp-bit);
ytail=yparent(vc,vp-bit+1:end);
xchild=xparent;
ychild=yparent;
xtail= flipud(xtail);
ytail= flipud(ytail);
xchild(vc,:)= [xhead xtail];
ychild(vc,:)= [yhead ytail];
end

function [xchild,ychild] = mutate(xp,yp,pos,Pm,obs,rad,poos)
xhead= xp(:,1);
xbody= xp(:,2:end-1);
xtail= xp(:,end);
yhead= yp(:,1);
ybody= yp(:,2:end-1);
ytail= yp(:,end);
%%mutasi dilakukan pada bagian tengah chromosome
Ppm=rand(size(xbody,1),size(xbody,2));
m_ind=find(Ppm < Pm);
child_ind=randsample(1:length(pos),length(m_ind),true,poos(4,:));
xbody(m_ind)= pos(1,child_ind);
ybody(m_ind)= pos(2,child_ind);
xchild= [xhead xbody xtail];
ychild= [yhead ybody ytail];
[test_result]=test_chr(xchild,ychild,obs,rad);
xchild(find(test_result == 0),:)=[];
ychild(test_result == 0,:)=[];
end
